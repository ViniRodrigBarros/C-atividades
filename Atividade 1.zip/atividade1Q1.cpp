#include <iostream>
#include <math.h>
using namespace std;
int main() {

//questão1 1) Faça um programa que imprima a raiz quadrada de um número qualquer lido do teclado.
  int num;
  cin>>num;
  num=sqrt(num);
  cout<<num;